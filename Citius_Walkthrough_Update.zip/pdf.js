(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./vendor/pdf-fonts.js'));else root.CitiusPDF=factory(root.CitiusCore,root.CitiusFonts);})(typeof globalThis!=='undefined'?globalThis:this,function(C,fonts){
'use strict';
const plain=s=>String(s??'').replace(/[–—−]/g,'-').replace(/[’‘]/g,"'").replace(/[“”]/g,'"').replace(/•/g,'-').replace(/[^\x20-\x7e\n\r\t\u00a0-\u00ff]/g,'');
const date=s=>{if(!s)return 'To be agreed';const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s);return m?`${Number(m[2])}/${Number(m[3])}/${m[1]}`:s;};
const expiry=q=>{const d=new Date(q.prepared+'T12:00:00');if(!Number.isFinite(d.getTime()))return 'To be confirmed';d.setDate(d.getDate()+C.num(q.validDays));return date(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`);};
const frequency=q=>q.mode==='once'?'One-time project':`${q.visits} visit(s) per week`;
const days=q=>q.mode==='once'?date(q.start):q.scheduleTbd?'Service days to be agreed':q.days.join(', ');
const period=f=>({once:'one-time',monthly:'per month',quarterly:'per quarter',visit:'per visit'}[f]||f);
function create(jsPDF,q,type,logo){
 const p=C.calc(q),doc=new jsPDF({unit:'pt',format:'letter'}),L=44,R=568,W=524,B=733;
 if(fonts){doc.addFileToVFS('CitiusSans-Regular.ttf',fonts.normal);doc.addFont('CitiusSans-Regular.ttf','CitiusSans','normal');doc.addFileToVFS('CitiusSans-Bold.ttf',fonts.bold);doc.addFont('CitiusSans-Bold.ttf','CitiusSans','bold');}
 const fontName=fonts?'CitiusSans':'helvetica';
 let y=0;
 const titles={proposal:'COMMERCIAL CLEANING PROPOSAL',internal:'INTERNAL WALKTHROUGH REPORT',agreement:'SERVICE AGREEMENT - DRAFT'};
 const title=titles[type]||titles.proposal;
 function header(first=false){
  doc.setFillColor(7,26,44);doc.rect(0,0,612,first?102:62,'F');
  if(first&&logo){const props=doc.getImageProperties(logo);const scale=Math.min(105/props.width,70/props.height);const w=props.width*scale,h=props.height*scale;doc.addImage(logo,props.fileType||'PNG',L,16,w,h);}
  doc.setTextColor(255,255,255);doc.setFont(fontName,'bold');doc.setFontSize(first?15:12);doc.text('CITIUS CLEANING COMPANY',first?165:L,first?39:28);
  doc.setFont(fontName,'normal');doc.setFontSize(8);doc.text(first?'(847) 660-3022  |  citiuscleaning.com':plain(q.quoteNumber)+'  |  Revision '+q.revision,first?165:L,first?56:44);
  if(first){doc.setFontSize(8);doc.setTextColor(127,204,255);doc.text(type==='internal'?'CONFIDENTIAL - INTERNAL USE ONLY':'Owner-led service. Exceptional standards.',165,73);}
  y=first?125:85;
 }
 function page(){doc.addPage();header(false);}
 function ensure(h){if(y+h>B)page();}
 function text(str,size=10,bold=false,color=[24,48,69],indent=0){doc.setFont(fontName,bold?'bold':'normal');doc.setFontSize(size);doc.setTextColor(...color);const ls=doc.splitTextToSize(plain(str||' '),W-indent);for(const line of ls){ensure(size+5);doc.text(line,L+indent,y);y+=size+5;}}
 function gap(n=8){ensure(n);y+=n;}
 function section(name){ensure(50);gap(9);doc.setDrawColor(210,225,236);doc.line(L,y-3,R,y-3);gap(12);text(name.toUpperCase(),9,true,[8,112,182]);gap(2);}
 function row(label,value,bold=false){const maxLeft=W-145;doc.setFont(fontName,bold?'bold':'normal');doc.setFontSize(9);const ls=doc.splitTextToSize(plain(label),maxLeft);ensure(ls.length*14+8);doc.setTextColor(24,48,69);ls.forEach((s,i)=>doc.text(s,L,y+i*14));doc.setFont(fontName,'bold');doc.text(plain(value),R,y,{align:'right'});y+=ls.length*14+6;}
 function total(label,value){ensure(45);doc.setFillColor(234,245,253);doc.roundedRect(L,y-10,W,32,4,4,'F');doc.setFont(fontName,'bold');doc.setFontSize(10);doc.setTextColor(6,91,147);doc.text(plain(label),L+10,y+10);doc.setFontSize(13);doc.text(C.money(value),R-10,y+10,{align:'right'});y+=40;}
 header(true);text(title,15,true,[8,112,182]);gap(3);text(`${q.quoteNumber}  |  Revision ${q.revision}  |  Prepared ${date(q.prepared)}`,8,false,[83,108,127]);
 if(type==='agreement')text('DRAFT FOR REVIEW - NOT EXECUTED',9,true,[152,49,49]);
 section('Customer & service location');text(q.company||'Customer',12,true);text('Contact: '+(q.contact||'Not specified'));text('Phone: '+(q.phone||'Not specified'));text('Email: '+(q.email||'Not specified'));text('Location: '+(q.address||'Not specified'));text('Facility: '+q.facilityType+(q.squareFeet?' | Approx. '+q.squareFeet+' sq. ft.':''));
 if(type==='agreement'){
  text('Service Provider: ZQME Solutions LLC, doing business as Citius Cleaning Company (C3)');
  text('Proposed Start Date: '+date(q.start));text('Service Frequency: '+frequency(q));
  text('Term: '+(q.term==='year'?'12-month fixed term beginning on the proposed start date':'Month-to-month beginning on the proposed start date'));text('Written Cancellation Notice: 60 days');
 }
 section(type==='agreement'?'1. Scope of services':'Cleaning scope');
 if(type==='agreement')text('C3 will provide the services checked during the facility walkthrough at the service location, subject to the agreed cleaning schedule and site access. Tasks not expressly included require separate written approval.');
 q.services.forEach(s=>text('- '+s,9));
 q.rooms.forEach(r=>{ensure(45);gap(7);text(r.name||'Area',10,true);if(r.area||r.floor)text([r.area?r.area+' sq. ft.':'',r.floor].filter(Boolean).join(' | '),9);text('Frequency: '+(r.frequency||'As agreed'),9);text(r.tasks||'Tasks to be confirmed',9);});
 if(q.exclusions){gap(7);text('Exclusions / customer responsibilities',10,true);text(q.exclusions,9);}
 section(type==='agreement'?'2. Facility details & schedule':'Facility & schedule');
 text(`Restrooms: ${q.restrooms} | Toilets: ${q.toilets} | Urinals: ${q.urinals} | Breakrooms: ${q.breakrooms}`,9);text('Frequency: '+frequency(q));text('Service days / date: '+days(q));text('Cleaning window: '+(q.timeWindow||'To be agreed'));text('Proposed start: '+date(q.start));if(q.accessNotes)text('Access arrangements: '+q.accessNotes,9);
 section(type==='agreement'?'3. Consumables':'Consumables & supplies');text(q.supplier==='citius'?'Citius provides selected consumables for the charge shown below.':'Customer provides consumables; Citius restocks selected items during scheduled visits.',9);text('Selected items: '+(q.supplyItems.join(', ')||'None selected'),9);
 ensure(Math.min(500,110+p.lines.length*36+(p.oneTime>0?45:0)));
 section(type==='agreement'?'4. Fees & payment':'Pricing');
 row(p.recurring?'Base monthly cleaning':'Base one-time cleaning',C.money(p.base));
 p.lines.forEach(c=>{row(`${c.name} (${c.quantity} x ${C.money(c.price)} ${p.recurring?period(c.frequency):'one-time'})`,C.money(c.amount));if(p.recurring&&['quarterly','visit'].includes(c.frequency))text('Monthly planning equivalent: '+C.money(c.monthly),8,false,[83,108,127]);});
 if(p.supplyCharge)row(p.recurring?'Monthly consumables charge':'Project consumables charge',C.money(p.supplyCharge));
 if(p.discount)row('Discount'+(q.discountReason?' - '+q.discountReason:''),'-'+C.money(p.discount));
 if(q.discountNotes&&p.discount)text('Discount notes: '+q.discountNotes,9);
 if(p.recurring)total(p.lines.some(c=>['quarterly','visit'].includes(c.frequency))?'RECURRING MONTHLY EQUIVALENT':'MONTHLY SERVICE TOTAL',p.monthly);
 if(p.oneTime>0)total(p.recurring?'SEPARATE ONE-TIME WORK':'ONE-TIME PROJECT TOTAL',p.oneTime);
 if(p.recurring&&p.lines.some(c=>['quarterly','visit'].includes(c.frequency)))text('The recurring total is a monthly planning equivalent. Quarterly and per-visit items are billed at their listed frequency, not again as monthly line items. Discounts are allocated proportionately across eligible cleaning charges.',8,false,[83,108,127]);
 if(p.recurring&&p.oneTime>0)text('One-time work is separate from the recurring service price and is performed only as agreed.',9);
 if(type==='internal'){
  section('Internal labor & profitability');text('NOT FOR CUSTOMER DISTRIBUTION',10,true,[152,49,49]);
  row('Cleaners per visit',String(q.cleaners));row('Hours per cleaner per visit',String(q.hours));row('Base person-hours '+(p.recurring?'per month (52/12 weeks)':'for project'),p.hours.toFixed(2));row('Hourly wage',C.money(q.wage));row('Payroll burden',q.burden+'%');
  row('Base labor including burden',C.money(p.labor));row('Cleaning supplies cost',C.money(q.suppliesCost));row('Travel / other cost',C.money(q.travelCost));row('Consumables purchase cost (included only if Citius supplies)',C.money(q.supplier==='citius'?q.consumablesCost:0));
  if(p.recurring){row('Recurring direct costs',C.money(p.recurringCosts));row('Recurring gross profit',C.money(p.profit));row('Recurring gross margin',p.margin.toFixed(1)+'%');}
  if(p.oneTime>0){row('One-time direct costs',C.money(p.onceCosts));row('One-time gross profit',C.money(p.onceProfit));row('One-time gross margin',p.onceMargin.toFixed(1)+'%');}
  p.lines.forEach(c=>text(`${c.name}: ${c.quantity} x (${c.hours} person-hours + ${C.money(c.cost)} other direct cost) ${period(c.frequency)}`,9));
  text('Estimates exclude general overhead, owner compensation, and taxes. Review all cost assumptions before approving a price.',9);
  const ws=C.warnings(q);if(ws.length){section('Review flags');ws.forEach(w=>text('- '+w.message,9));}
  if(q.internalNotes){section('Internal notes');text(q.internalNotes,9);}
 }
 if(q.notes&&type!=='agreement'){section('Scope notes');text(q.notes,9);}
 if(type==='agreement'){
  section('5. Term & cancellation');
  text(q.term==='year'?'This agreement has a 12-month initial term beginning on the proposed start date. Either party must provide at least 60 days written notice to end services at the conclusion of the initial term. Without timely notice, service continues month-to-month thereafter, terminable by either party on 60 days written notice. Any early termination during the initial 12-month term must be mutually agreed in writing. Fees for services performed remain payable.':'This agreement continues month-to-month. Either party may terminate cleaning services by providing at least 60 days written notice. Fees for services performed through the termination date remain payable.',9);
  section('6. Access, safety & service changes');text('Customer will provide safe, timely access, necessary utilities, and relevant site instructions. Both parties will communicate material safety hazards, service issues, and requested scope changes promptly. Any changes to the agreed scope, frequency, or price must be documented in writing.',9);
  section('7. Insurance, damage & disputes');text('Insurance requirements, allocation of liability for property damage, claim reporting, dispute resolution, and any limitation of liability must be completed and approved by legal counsel before execution.',9);
  section('8. Walkthrough notes / special instructions');text(q.notes||'None provided.',9);
  section('9. Acceptance');text('By signing a finalized version, the parties agree to its stated scope, pricing, schedule, and terms. This document is a draft until reviewed, completed, and signed by authorized representatives.',9);
  ensure(160);gap(20);text('CUSTOMER AUTHORIZED SIGNATURE: ______________________________',9,true);gap(12);text('Printed Name / Title: ____________________  Date: ______________',9);gap(20);text('CITIUS AUTHORIZED SIGNATURE: _________________________________',9,true);gap(12);text('Printed Name / Title: ____________________  Date: ______________',9);
 }
 section(type==='agreement'?'Payment terms':'Proposal details');
 if(type==='agreement')text('Invoices are due '+q.due+' days after invoice date. Additional work requires separate written approval and may incur additional charges.',9);
 else {text('Valid through: '+expiry(q)+' ('+q.validDays+' days from prepared date).',9);text('This proposal is an estimate. Final scope, schedule, pricing and terms are subject to confirmation in a signed service agreement.',9);}
 const count=doc.getNumberOfPages();for(let n=1;n<=count;n++){doc.setPage(n);doc.setDrawColor(210,225,236);doc.line(L,756,R,756);doc.setTextColor(83,108,127);doc.setFont(fontName,'normal');doc.setFontSize(8);doc.text(plain(q.quoteNumber)+' | Rev '+q.revision,L,771);doc.text(`${n} / ${count}`,R,771,{align:'right'});}
 return doc;
}
return {create,date,expiry,frequency,days,period};
});
