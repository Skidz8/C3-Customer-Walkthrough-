const CACHE='citius-walkthrough-v2.0.0';
const ASSETS=['./','./index.html','./styles.css','./core.js','./pdf.js','./app.js','./assets/citius-logo.png','./vendor/jspdf.umd.min.js','./vendor/pdf-fonts.js','./manifest.webmanifest'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('citius-walkthrough-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('message',event=>{if(event.data==='SKIP_WAITING')self.skipWaiting();});
self.addEventListener('fetch',event=>{
 const u=new URL(event.request.url);if(event.request.method!=='GET'||u.origin!==self.location.origin||!u.pathname.startsWith(new URL(self.registration.scope).pathname))return;
 const scopePath=new URL(self.registration.scope).pathname;
 if(event.request.mode==='navigate' && u.pathname!==scopePath && u.pathname!==scopePath+'index.html')return;
 if(event.request.mode==='navigate'){event.respondWith(caches.match('./index.html').then(cached=>cached||fetch(event.request)));return;}
 // Each release caches its full, matching asset set. Updates activate only after user approval.
 event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request)));
});
