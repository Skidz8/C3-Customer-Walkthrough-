(function(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CitiusCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function() {
  'use strict';
  const VERSION = '2.0.0';
  const SERVICES = ['Trash Removal', 'Vacuuming', 'Hard-Floor Cleaning', 'Dusting', 'Common Areas', 'High-Touch Disinfecting', 'Restroom Cleaning & Sanitizing', 'Breakroom / Kitchenette Cleaning', 'Recycling Collection', 'Entryways & Lobby Cleaning', 'Spot Cleaning Interior Glass', 'Spot Cleaning Walls & Doors', 'Conference Room Cleaning', 'Stairwell Cleaning', 'Elevator Cleaning', 'Cobweb Removal (reachable)'];
  const SUPPLIES = ['Trash Bags / Liners', 'Toilet Paper', 'Paper Towels', 'Hand Soap', 'Urinal Screens / Deodorizer Blocks', 'Air Fresheners', 'Other Supplies'];
  const num = value => Math.max(0, Number.isFinite(Number(value)) ? Number(value) : 0);
  const money = n => new Intl.NumberFormat('en-US', {style:'currency', currency:'USD', minimumFractionDigits:2}).format(Number.isFinite(n) ? n : 0);
  const today = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const id = () => (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : 'q-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10));
  function defaults() {
    const key=id();
    return {id:key, quoteNumber:'CIT-'+today().replaceAll('-','')+'-'+key.slice(-5).toUpperCase(), revision:1, prepared:today(), validDays:30, mode:'recurring', company:'', contact:'', phone:'', email:'', address:'', squareFeet:'', facilityType:'Office', restrooms:2, toilets:2, urinals:0, breakrooms:1, services:SERVICES.slice(0,5), rooms:[], visits:3, days:[], scheduleTbd:true, timeWindow:'', accessNotes:'', exclusions:'', notes:'', base:1500, autoBase:true, supplier:'customer', supplyItems:[], supplyCharge:150, discountType:'none', discountValue:0, discountReason:'', discountNotes:'', charges:[], cleaners:1, hours:2, wage:17, burden:15, suppliesCost:50, consumablesCost:0, travelCost:0, targetMargin:45, internalNotes:'', start:'', term:'month', due:15, updatedAt:new Date().toISOString()};
  }
  function calc(q) {
    const recurring=q.mode!=='once';
    const visits=recurring ? Math.min(7, Math.max(1, Math.round(num(q.visits)))) : 1;
    const monthlyVisits=recurring ? visits*52/12 : 1;
    const base=num(q.base);
    let recurringExtras=0, onceExtras=0, recurringExtraCosts=0, onceExtraCosts=0;
    const wage=num(q.wage), burden=num(q.burden)/100;
    const lines=(q.charges||[]).map(item=>{
      const quantity=num(item.quantity), amount=num(item.price)*quantity;
      const cost=(num(item.hours)*wage*(1+burden)+num(item.cost))*quantity;
      const multiplier=!recurring || item.frequency==='once' ? 0 : item.frequency==='quarterly' ? 1/3 : item.frequency==='visit' ? monthlyVisits : 1;
      const monthly=amount*multiplier, oneTime=multiplier===0?amount:0;
      recurringExtras+=monthly; onceExtras+=oneTime;
      recurringExtraCosts+=cost*multiplier; onceExtraCosts+=multiplier===0?cost:0;
      return {...item, quantity, amount, monthly, oneTime, allocatedCost:cost};
    });
    const eligible=base+(recurring?recurringExtras:onceExtras);
    const discount=q.discountType==='percent' ? Math.min(eligible,eligible*Math.min(100,num(q.discountValue))/100) : q.discountType==='fixed' ? Math.min(eligible,num(q.discountValue)) : 0;
    const supplyCharge=q.supplier==='citius'?num(q.supplyCharge):0;
    const monthly=recurring?eligible-discount+supplyCharge:0;
    const oneTime=recurring?onceExtras:eligible-discount+supplyCharge;
    const hours=monthlyVisits*num(q.cleaners)*num(q.hours);
    const labor=hours*wage*(1+burden);
    const baseCosts=labor+num(q.suppliesCost)+num(q.travelCost)+(q.supplier==='citius'?num(q.consumablesCost):0);
    const recurringCosts=recurring?baseCosts+recurringExtraCosts:0;
    const onceCosts=recurring?onceExtraCosts:baseCosts+onceExtraCosts;
    const profit=monthly-recurringCosts, onceProfit=oneTime-onceCosts;
    return {recurring, visits, monthlyVisits, base, discount, supplyCharge, recurringExtras, onceExtras, monthly, oneTime, hours, labor, recurringCosts, onceCosts, profit, onceProfit, margin:monthly>0?profit/monthly*100:0, onceMargin:oneTime>0?onceProfit/oneTime*100:0, lines};
  }
  function warnings(q) {
    const p=calc(q), out=[];
    const add=(message, blocking=false)=>out.push({message,blocking});
    if(!q.quoteNumber.trim())add('Enter a quote number.',true);
    if(!/^\d{4}-\d{2}-\d{2}$/.test(q.prepared)||!Number.isFinite(new Date(q.prepared+'T12:00:00').getTime()))add('Enter a valid prepared date.',true);
    if(!q.company.trim())add('Enter the customer company name.',true);
    if(!q.address.trim())add('Enter the service property address.',true);
    if(q.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(q.email))add('Correct the customer email address or leave it blank.',true);
    if(!q.services.length && !q.rooms.some(r=>r.tasks.trim()))add('Select at least one cleaning task or enter a room scope.',true);
    if(num(q.cleaners)<1 || num(q.hours)<=0 || num(q.wage)<=0)add('Labor estimates are incomplete; review the internal margin.',true);
    if(p.recurring && !q.scheduleTbd && q.days.length!==p.visits)add('Selected service days do not match the visits per week.',true);
    if(p.monthly+p.oneTime<=0)add('The proposal must have a positive service price.',true);
    if(q.mode==='recurring' && p.monthly<=0)add('Recurring service needs a positive monthly price.',true);
    const negativeFields=['base','visits','cleaners','hours','wage','burden','suppliesCost','travelCost','supplyCharge','consumablesCost','discountValue'];
    if(negativeFields.some(k=>!Number.isFinite(Number(q[k]))||Number(q[k])<0))add('Correct negative or invalid pricing and labor values.',true);
    if(q.discountType==='percent' && num(q.discountValue)>100)add('Percentage discounts cannot exceed 100%.',true);
    if(q.charges.some(c=>!c.name.trim()||num(c.quantity)<=0||[c.price,c.quantity,c.hours,c.cost].some(n=>!Number.isFinite(Number(n))||Number(n)<0)))add('Each additional service needs a name, positive quantity, and valid nonnegative amounts.',true);
    if(!q.email)add('No customer email is entered. Download and sharing are still available.');
    if(p.recurring && p.margin<num(q.targetMargin))add(`Recurring gross margin is ${p.margin.toFixed(1)}%, below your ${num(q.targetMargin)}% target.`);
    if(p.oneTime>0 && p.onceMargin<num(q.targetMargin))add(`One-time gross margin is ${p.onceMargin.toFixed(1)}%, below your ${num(q.targetMargin)}% target.`);
    if(q.charges.some(c=>num(c.price)>0&&num(c.hours)===0&&num(c.cost)===0))add('Some extra services have no additional labor or direct cost estimate. Their margin may be overstated.');
    if(q.supplier==='citius' && num(q.supplyCharge)>0 && num(q.consumablesCost)===0)add('Enter your expected consumables purchasing cost; it is currently zero.');
    if(q.discountReason==='Yearly contract discount' && q.mode!=='once' && q.term!=='year')add('A yearly contract discount requires a 12-month agreement term.',true);
    if(num(q.validDays)<1||num(q.due)<1)add('Quote validity and invoice payment days must be at least 1.',true);
    if(!q.scheduleTbd && p.recurring && !q.timeWindow.trim())add('No preferred cleaning window is entered.');
    return out;
  }
  function clean(raw) {
    if(!raw || typeof raw!=='object' || Array.isArray(raw))throw new Error('Invalid customer record.');
    const q=defaults();
    const stringKeys=['id','quoteNumber','prepared','mode','company','contact','phone','email','address','squareFeet','facilityType','timeWindow','accessNotes','exclusions','notes','supplier','discountType','discountReason','discountNotes','internalNotes','start','term','updatedAt'];
    stringKeys.forEach(k=>{if(typeof raw[k]==='string')q[k]=raw[k].slice(0,['notes','internalNotes','exclusions'].includes(k)?15000:2000);});
    ['revision','validDays','restrooms','toilets','urinals','breakrooms','visits','base','supplyCharge','discountValue','cleaners','hours','wage','burden','suppliesCost','consumablesCost','travelCost','targetMargin','due'].forEach(k=>{if(raw[k]!==undefined){const n=Number(raw[k]);if(!Number.isFinite(n)||n<0)throw new Error('Invalid numeric value: '+k);q[k]=n;}});
    ['autoBase','scheduleTbd'].forEach(k=>{if(typeof raw[k]==='boolean')q[k]=raw[k];});
    q.mode=q.mode==='once'?'once':'recurring';q.supplier=q.supplier==='citius'?'citius':'customer';q.term=q.term==='year'?'year':'month';
    q.discountType=['none','percent','fixed'].includes(q.discountType)?q.discountType:'none';
    if(q.visits<1||q.visits>7||!Number.isInteger(q.visits)||q.revision<1||q.revision>100000||q.validDays<1||q.validDays>3650||q.due<1||q.due>3650||q.targetMargin>=100)throw new Error('Invalid schedule, revision, or settings.');
    q.services=Array.isArray(raw.services)?raw.services.filter(x=>SERVICES.includes(x)):q.services;
    q.supplyItems=Array.isArray(raw.supplyItems)?raw.supplyItems.filter(x=>SUPPLIES.includes(x)):[];
    q.days=Array.isArray(raw.days)?[...new Set(raw.days.filter(x=>['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].includes(x)))]:[];
    q.rooms=(Array.isArray(raw.rooms)?raw.rooms:[]).slice(0,100).map(r=>({name:String(r.name||'').slice(0,300),area:String(r.area||'').slice(0,100),floor:String(r.floor||'').slice(0,200),frequency:String(r.frequency||'Each visit').slice(0,200),tasks:String(r.tasks||'').slice(0,5000)}));
    q.charges=(Array.isArray(raw.charges)?raw.charges:[]).slice(0,100).map(c=>{
      if([c.price,c.quantity,c.hours,c.cost].some(x=>!Number.isFinite(Number(x))||Number(x)<0))throw new Error('Invalid additional service amount.');
      return {id:String(c.id||id()).slice(0,100),name:String(c.name||'').slice(0,300),frequency:['once','monthly','quarterly','visit'].includes(c.frequency)?c.frequency:'once',price:num(c.price),quantity:num(c.quantity),hours:num(c.hours),cost:num(c.cost)};
    });
    return q;
  }
  function migrate(old) {
    const q=defaults(), map={companyName:'company',contactName:'contact',customerPhone:'phone',customerEmail:'email',propertyAddress:'address',squareFeet:'squareFeet',restroomCount:'restrooms',toiletCount:'toilets',urinalCount:'urinals',breakroomCount:'breakrooms',supplyCharge:'supplyCharge',discountType:'discountType',discountValue:'discountValue',discountReason:'discountReason',discountNotes:'discountNotes',laborCleaners:'cleaners',laborHours:'hours',laborWage:'wage',laborBurden:'burden',internalSupplies:'suppliesCost',internalConsumableCost:'consumablesCost',internalTravel:'travelCost',internalNotes:'internalNotes',walkthroughNotes:'notes',contractStart:'start',contractTerm:'term',contractDue:'due'};
    for(const [from,to] of Object.entries(map))if(old[from]!==undefined)q[to]=typeof q[to]==='number'?num(old[from]):String(old[from]);
    q.visits=Math.min(7,Math.max(1,num(old.visits)||3));q.base=q.visits*500;q.supplier=old.supplier==='c3'?'citius':'customer';
    const selected=Array.isArray(old.services)?old.services:[];
    q.services=SERVICES.filter(x=>selected.includes(x));q.supplyItems=SUPPLIES.filter(x=>selected.includes(x));
    const extras=[['Interior Glass',75],['Deep Cleaning',200],['Carpet Service',150],['Floor Scrub / Buff',200],['Extra Day of Cleaning',500]];
    extras.forEach(([name,price])=>{if(selected.some(x=>x.startsWith(name+' +$')))q.charges.push({id:id(),name:name==='Extra Day of Cleaning'?'Legacy extra day - review schedule & labor':name,price,quantity:1,frequency:'monthly',hours:0,cost:0});});
    if(num(old.misc))q.charges.push({id:id(),name:'Miscellaneous - review scope',price:num(old.misc),quantity:1,frequency:'monthly',hours:0,cost:0});
    q.internalNotes+='\nImported from the previous app. Confirm pricing frequency, schedule, and extra-service labor before sending.';
    return clean(q);
  }
  return {VERSION,SERVICES,SUPPLIES,num,money,today,id,defaults,calc,warnings,clean,migrate};
});
