# Citius Walkthrough & Proposals

A static, mobile-friendly customer walkthrough app for Citius Cleaning Company. Version 2 replaces the single-screen sample with five steps: Customer, Scope, Pricing, Internal Review, and Proposal.

## Use

Open the existing GitHub Pages URL. Customer View hides internal controls and figures; it is a presentation mode, not authentication. The public repository contains application code and synthetic tests, not a customer database.

- Save multiple named customer records, search, reopen, and duplicate quotes. New Customer saves an edited walkthrough first; it does not erase previous customers.
- Drafts autosave in this browser and are offered for explicit recovery on the next opening. Existing data under `c3_walkthrough_sample` is copied into the new library without deleting the original.
- Back up customer data regularly using Backup / restore. Data is local to the browser, is not encrypted by this app, and is not synchronized between devices. Restore adds separate copies and does not overwrite existing customers. Keep backup files private.
- Customer proposal, internal report, and draft agreement PDFs are separate. Internal wages, direct costs, margin, and internal notes do not appear in customer proposal or agreement PDFs.
- Preview and download PDFs locally. Share PDF invokes a supported device share sheet. It does not automatically email an attachment or verify delivery. Email text summary opens the configured email composer with no attachment.
- The existing recurring agreement remains a **draft**, including the unfinished insurance/damage/dispute section. Annual-discount linkage, 12-month term behavior, 60-day written cancellation notice, and blank signatory fields are preserved. The recurring agreement template is disabled for one-time projects.

## Pricing

The recurring starting estimate remains $500 per weekly cleaning visit. It follows the weekly visit count until the base price is edited. A custom base price does not silently change when the schedule changes. Use the internal suggested-price tool to calculate a base price from entered costs and a target margin, then explicitly apply it.

Base labor uses visits/week × 52/12 × cleaners × hours/cleaner. One-time projects use one occurrence. Additional services each have a unit price, quantity, billing frequency, extra person-hours per unit, and other direct cost per unit. Do not count extra-service labor again in base labor.

- Monthly: allocate one occurrence each month.
- Quarterly: price and cost divided by three for monthly planning; billing remains per quarter.
- Per visit: price and cost multiplied by estimated monthly visits (52/12 weeks).
- One-time: excluded from recurring revenue/margin and shown with separate profitability.

Recurring totals containing quarterly or per-visit services are **monthly planning equivalents**, not a fixed monthly invoice total. Billing frequency is stated on each line. Discounts apply to eligible cleaning, excluding consumables and separate one-time work; the agreement/proposal explains proportional allocation. Costs exclude overhead, taxes, and owner compensation. No margin estimate substitutes for a complete scope and cost assessment.

## Offline & updates

All PDF code, fonts, and the approved logo are served from this repository. After a successful initial online visit and service-worker installation, the installed asset set can work offline. Browser storage availability and retention are device dependent. PDF email delivery still depends on the selected mail/sharing app and connectivity.

For a later release, change the version in `core.js`, the cache key in `sw.js`, and any added files in the cache list. A waiting update prompts the user to save a draft and reload. Keep navigation and static assets on the same cached release to avoid mixed versions. Preview page `preview.html` embeds the app at 390px width for layout review; it does not emulate iOS Safari sharing.

## Development & verification

No build step. Serve the root over HTTP locally, or deploy the root to GitHub Pages. Use HTTPS for offline support.

```
npm ci
npm test
```

Tests cover pricing allocation, discounts, variable visit labor, one-time project math, migration, saved customers/revisions, draft recovery, corrupted-storage protection, customer presentation mode, and PDF pagination. Test data is synthetic. Final iPhone Safari/Home Screen sharing must also be checked on a real device.

## Dependencies

- Vendored jsPDF 2.5.1 (MIT license retained in its header).
- Subset DejaVu Sans regular/bold for consistent embedded PDF text; license in `vendor/DejaVu-LICENSE.txt`.
- jsdom is a development-only dependency for DOM workflow tests. It is not loaded in the customer app.

The original application is retained in Git history, with a pre-upgrade backup branch.
